#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

PROFILE=EXAMPLE_MNX	

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"
./lolMiner --benchmark MNX --shortstats 5 --longstats 60 $@
./lolMiner --benchmark AION --shortstats 5 --longstats 60 $@
./lolMiner --benchmark BTG --shortstats 5 --longstats 60 $@
./lolMiner --benchmark ZER --shortstats 5 --longstats 60 $@
